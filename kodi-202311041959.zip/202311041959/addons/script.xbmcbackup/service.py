from resources.lib.scheduler import BackupScheduler

# start the backup scheduler
BackupScheduler().start()
